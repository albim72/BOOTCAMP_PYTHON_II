import random

class Losowanie:
    def __init__(self):
        self.wylosowane = random.choice(["O", "R"])
    def __str__(self):
        return self.wylosowane

class Wybor:
    def __init__(self):
        print("Wybierz O - orzeł, R - reszka, Q - koniec zabawy")
        self.wybrane = str(input("Podaj swój wybór: "))
    def __str__(self):
        return self.wybrane

class Gra:
    def __init__(self):
        self.losowanie = Losowanie()
        self.wybor = Wybor()
        self.rezultat = str(self.wybor) == str(self.losowanie)