print("------------- ORZEŁ RESZKA KLASY ------------------")

from klasy import Gra

suma_gier = 0
suma_zwyciestw = 0

while True:
    x = Gra()
    if str(x.wybor) not in ("O", "R", "Q"):
        print("Nieprawidłowy wybór. Wybierz jeszcze raz!!!")
        continue
    elif str(x.wybor) == "Q":
        break
    else:
        suma_gier += 1
        print(f"...3...2...1... komputer wylosował: {x.losowanie}")
        if x.rezultat == True:
            print("WYGRAŁEŚ!!!")
        else:
            print("PRZEGRAŁEŚ")
        print(f"Dostajesz {int(x.rezultat)} punktów.")
        suma_zwyciestw += x.rezultat
        print(f"Zwyciężyłeś: {suma_zwyciestw} rany na {suma_gier} gier.")
