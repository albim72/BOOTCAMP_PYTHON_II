from rezyser import Rezyser

class Film(Rezyser):
    pass

