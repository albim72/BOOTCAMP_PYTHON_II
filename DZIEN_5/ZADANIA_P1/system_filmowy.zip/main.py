from system import *

s = System()
print(s)
print()