from konto import Konto
from film import Film
from zarzadzanie import IZarzadzenieKontem
from szukanie import ISzukanie

class System(Konto,Film,IZarzadzenieKontem,ISzukanie):
    pass