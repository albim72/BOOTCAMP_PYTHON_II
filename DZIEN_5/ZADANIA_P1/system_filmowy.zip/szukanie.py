from abc import ABC,abstractmethod

class ISzukanie(ABC):
    pass
