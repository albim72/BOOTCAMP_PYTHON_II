class Uzytkownik:
    pass