from abc import ABC,abstractmethod

class IZarzadzenieKontem(ABC):
    pass