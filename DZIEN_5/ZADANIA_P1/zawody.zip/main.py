from rejestracja import Rejestracja,Biegacz,Zawody

b1 = Biegacz(89,"Leon","Nowak",30,"Tarnów","877665544",78,175,"m")

print(b1.printdane())


b1.miasto = "Rzeszów"


rej1 = Rejestracja(6,"Olga","Kot",26,"Kraków","677888999",54,170,"k",234,390,"7:00",2,"Tatra Sky Marathon",
                   42,"Zakopane",600,350)

print(rej1.printrejstracja())
print(rej1.print_zawody())
