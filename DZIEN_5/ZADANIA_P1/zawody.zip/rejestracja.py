from biegacz import Biegacz
from zawody import Zawody

class Rejestracja(Biegacz,Zawody):

    def __init__(self,id,imie,nazwisko,wiek,miasto,telefon,waga,wzrost,plec,nr_startowy,oplata,godzina_start,
                 idzawodow,nazwa,dlugosc_trasy,miejsce,limit_czasowy,liczba_zawodnikow):
        Biegacz.__init__(self,id,imie,nazwisko,wiek,miasto,telefon,waga,wzrost,plec)
        Zawody.__init__(self,idzawodow,nazwa,dlugosc_trasy,miejsce,limit_czasowy,liczba_zawodnikow)
        self.nr_startowy = nr_startowy
        self.oplata = oplata
        self.godzina_start = godzina_start

    @property
    def godzina_start(self):
        return self._godzina_start

    @godzina_start.setter
    def godzina_start(self,godzina_start):
        self._godzina_start = godzina_start

    def printrejstracja(self):
        return f"poprawny proces rejestracji  potwierdzenie: zawodnik -> imię: {self.imie}, nazwisko: {self.nazwisko}, " \
               f"miasto {self.miasto}, wybór zawodów: -> {self.nazwa}, nr_startowy: {self.nr_startowy}, " \
               f"godzina startu: {self.godzina_start}"

    def print_zawody(self):
        return super().print_zawody()

    def nr_edycji(self,nr):
        return f"{nr} edycja zawodów"

